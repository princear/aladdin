export const SPLASH = require('./images/splash_icon.png');
export const LEFT_ARROW = require('./images/left-arrow.png');
export const USER_PROFILE = require('./images/userProfile.png');
export const MOBILE = require('./images/mobile.png');
export const LOCK = require('./images/lock.png');
export const SERVICES = require('./images/userTelephone.png');
export const LOCATION = require('./images/location.png');
export const BAR = require('./images/menubarecopy.png');
export const SEARCH = require('./images/Searchh.png');
export const CLOCK = require('./images/clock.png');
export const DATE = require('./images/date.png');
export const ARROW_WHITE = require('./images/backwhitecolour.png');
export const DOWN_ARROW = require('./images/downbutton.png');
export const SERACH_GREY = require('./images/Searchgray.png');
export const WHITE_EDIT = require('./images/Edit.png');
export const DELETE = require('./images/Delete.png');
export const EYE = require('./images/Show.png');
export const CLOSE_BUTTON = require('./images/closeingray.png');
export const EMAIL = require('./images/Email.png');
export const CONTACT = require('./images/contactno.png');
export const LOGIN_BACKGROUND = require('./images/loginbackground.png');
export const LOGO_ALLADIN = require('./images/LogoAlladin.png');
export const SPLASH_BACKGROUND = require('./images/Splashscreenbackground.png');
export const FORGET_IMAGE = require('./images/forget.png');
export const OTP = require('./images/OTP.png');





















