//Designed By Pradeep Gupta
/* eslint-disable no-shadow */
/* eslint-disable global-require */
/* eslint-disable react/jsx-props-no-spreading */
import React, { useEffect, useState } from 'react';
import { DrawerContentScrollView, DrawerItemList, DrawerItem } from '@react-navigation/drawer';

import { Alert, Linking, StyleSheet, View } from 'react-native';


import { hp, RF, wp } from '../ui/styles/responsive';


const DrawerContent = (props) => {
 


  return (
    <View style={styles.drawerContainer}>
      <Text> abbbb   </Text>
    </View>
  );
};

export default DrawerContent;

const styles = StyleSheet.create({
  drawerContainer: { flex: 1, backgroundColor: '#000' },
 
 
});
