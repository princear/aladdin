export const LOGINUSER = 'service-provider-login';
export const COUNTBOOKING = 'get-count-provider-bookings'

