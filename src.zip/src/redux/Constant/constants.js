export const LOADER = 'LOADER';
export const SIGNUP = 'SIGNUP';
export const LOGIN = 'LOGIN';
export const COUNT = 'COUNT';
export const SEND_OTP = 'SEND_OTP';
export const FORGOT_SEND_OTP = 'FORGOT_SEND_OTP';
export const VERIFY_OTP = 'VERIFY_OTP';
export const RESEND_OTP = 'RESEND_OTP';

export const VERIFY_RESEND_OTP = 'VERIFY_RESEND_OTP';
export const PRODUCT_ID = 'PRODUCT_ID';
export const DETAIL_PRODUCT = 'DETAIL_PRODUCT';
export const CREATE_PASSWORD = 'CREATE_PASSWORD';
export const USER_LOGIN = 'USER_LOGIN';
export const GET_TOKEN = 'GET_TOKEN';
export const REMOVE_TOKEN = 'REMOVE_TOKEN';
export const GET_SERVICES = 'GET_SERVICES';
export const COMPANY_LIST = 'COMPANY_LIST';
export const BOOKINGLIST = 'BOOKINGLIST';
export const BOOKING_LIST_ID = 'BOOKING_LIST_ID';


