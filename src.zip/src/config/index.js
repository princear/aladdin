export const Globals = {

  // baseUrl: 'http://3.26.216.78/api',
  // baseUrl: 'http://3.25.135.48/api'
  baseUrl: 'https://aladdin.com.iq/api'
  // baseUrl: 'http://54.252.68.169/api'


};
