export const MONTSERRAT_BLACK= 'Montserrat-Black';
export const MONTSERRAT_BOLD= 'Montserrat-Bold';
export const MONTSERRAT_REGULAR= 'Montserrat-Regular';
export const MONTSERRAT_MEDIUM= 'Montserrat-Medium';




