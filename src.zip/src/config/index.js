export const Globals = {
  
    baseUrl: 'http://3.26.216.78/api',
   
  };
  